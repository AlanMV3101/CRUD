package com.example.pacato_alunos;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pacato_alunos.dao.AlunoDAO;
import com.example.pacato_alunos.model.Aluno;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int MIN_CPF_LENGTH = 9;
    private static final int MIN_TELEFONE_LENGTH = 11;

    private EditText edtNome;
    private EditText edtCpf;
    private EditText edtTel;
    private EditText edtListar;
    private AlunoDAO dao;
    private List<Aluno> alunos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("CRUD - Android Studio");

        edtNome = findViewById(R.id.edtNome);
        edtCpf = findViewById(R.id.edtCpf);
        edtTel = findViewById(R.id.edtTelefone);
        edtListar = findViewById(R.id.edtListar);
    }

    @SuppressLint("DefaultLocale")
    public void salvar(View view) {
        Aluno aluno = new Aluno();

        if (edtNome.getText() == null || edtNome.getText().toString().length() <= 2) {
            edtNome.setError("O NOME precisa ter mais de 2 caracteres.");
            return;
        }
        aluno.setNome(edtNome.getText().toString());

        if (edtCpf.getText().toString().length() <= MIN_CPF_LENGTH) {
            edtCpf.setError("O CPF precisa ter mais de 9 caracteres.");
            return;
        }
        aluno.setCpf(edtCpf.getText().toString());

        String telefone = edtTel.getText().toString();
        if (telefone.length() < MIN_TELEFONE_LENGTH) {
            edtTel.setError("O TELEFONE precisa ter mais de 10 caracteres e ter DDD.");
            return;
        }
        aluno.setTelefone(telefone);

        if (dao == null) {
            dao = new AlunoDAO(this);
        }
        long id = dao.insert(aluno);
        Toast.makeText(getApplicationContext(),String.format("Aluno %s com o id %d cadastrado com sucesso!", aluno.getNome(), id),Toast.LENGTH_LONG).show();
    }

    public void listar(View view) {
        limpar(view);
        dao = new AlunoDAO(this);
        alunos = dao.obterAlunos();
        for (Aluno aluno : alunos) {
            edtListar.append("\nID: " + aluno.getId() + "\n");
            edtListar.append("Nome: " + aluno.getNome() + "\n");
            edtListar.append("CPF: " + aluno.getCpf() + "\n");
            edtListar.append("Telefone: " + aluno.getTelefone() + "\n");
        }
    }

    public void limpar(View view){
        edtNome.setText(null);
        edtCpf.setText(null);
        edtTel.setText(null);
        edtListar.setText(null);
    }
    public void manutencao(View view){
        Intent it = new Intent(getApplicationContext(), Manutencao.class);
        startActivity(it);
    }
}