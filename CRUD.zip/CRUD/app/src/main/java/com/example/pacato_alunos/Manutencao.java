package com.example.pacato_alunos;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.pacato_alunos.dao.AlunoDAO;
import com.example.pacato_alunos.model.Aluno;

public class Manutencao extends AppCompatActivity {

    private EditText edtID;
    private EditText edtNome;
    private EditText edtCpf;
    private EditText edtTel;
    private AlunoDAO dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_manutencao);
        setTitle("CRUD - Android Studio");

        edtNome = findViewById(R.id.edtNome);
        edtCpf = findViewById(R.id.edtCpf);
        edtTel = findViewById(R.id.edtTelefone);
        edtID = findViewById(R.id.edtID);
    }

    public void consultar(View view) {
        dao = new AlunoDAO(this);
        if (edtID.getText().toString().length() >= 1 && edtID.getText() != null) {
            Aluno aluno = dao.read(Integer.parseInt(edtID.getText().toString()));

            if (aluno.getId() == null) {
                Toast.makeText(this, "Nenhum aluno foi encontrado!", Toast.LENGTH_SHORT).show();
                return;
            }

            edtNome.setText(aluno.getNome());
            edtCpf.setText(aluno.getCpf());
            edtTel.setText(aluno.getTelefone());
        } else {
            edtID.setError("ID é obrigatório!");
            Toast.makeText(getApplicationContext(), "ID não informado, favor verificar!", Toast.LENGTH_LONG).show();
        }
    }

    public void alterar(View view) {
        Aluno aluno = new Aluno();

        if (edtID.getText().toString().length() >= 1 && edtID.getText() != null) {
            aluno.setId(Integer.parseInt(edtID.getText().toString()));

            if (isValidInput(edtNome.getText().toString(), 3)) {
                aluno.setNome(edtNome.getText().toString());
            } else {
                edtNome.setError("O NOME precisa ter mais de 2 caracteres.");
                return;
            }

            if (isValidInput(edtCpf.getText().toString(), 10)) {
                aluno.setCpf(edtCpf.getText().toString());
            } else {
                edtCpf.setError("O CPF precisa ter mais de 9 caracteres.");
                return;
            }

            if (isValidInput(edtTel.getText().toString(), 11)) {
                aluno.setTelefone(edtTel.getText().toString());
            } else {
                edtTel.setError("O TELEFONE precisa ter mais de 10 caracteres e ter DDD.");
                return;
            }

            AlunoDAO dao = new AlunoDAO(this);
            dao.update(aluno);
            Toast.makeText(getApplicationContext(), "Alteração Realizada Com Sucesso", Toast.LENGTH_LONG).show();
        } else {
            edtID.setError("ID é obrigatório!");
            Toast.makeText(getApplicationContext(), "ID não informado, favor verificar!", Toast.LENGTH_LONG).show();
        }
    }

    private boolean isValidInput(String input, int minLength) {
        return input != null && input.length() >= minLength;
    }

    public void excluir(View view) {
        Aluno aluno = new Aluno();

        edtID.getText().toString();
        if (edtID.getText().toString().length() >= 1) {
            aluno.setId(Integer.parseInt(edtID.getText().toString()));
            dao = new AlunoDAO(this);
            dao.delete(aluno);
            Toast.makeText(getApplicationContext(), "Exclusão Realizada com Sucesso", Toast.LENGTH_LONG).show();
            limpar(view);
        } else {
            edtID.setError("ID é obrigatório!");
            Toast.makeText(getApplicationContext(), "ID não informado, favor verificar!", Toast.LENGTH_LONG).show();
        }
    }

    public void limpar(View view) {
        edtNome.setText(null);
        edtCpf.setText(null);
        edtTel.setText(null);
        edtID.setText(null);
    }

    public void voltar(View view) {
        finish();
    }
}